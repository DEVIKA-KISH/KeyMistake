 KeyMistake++ — Cryptography CTF Challenge

We've intercepted an encrypted message and its corresponding plaintext. Unfortunately, the attacker reused the same XOR key to encrypt another sensitive message — the FLAG.

Can you recover the key and decrypt the flag?


How to Play:
Connect to the server using:
 
 nc <your_ip_or_ngrok_url> 1337 
