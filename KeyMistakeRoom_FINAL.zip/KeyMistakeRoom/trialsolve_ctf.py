# solve_ctf.py

# Correct ciphertext (hex string cleaned up)
cipher_hex = "271d1916521e16410a4b0e171c021e451f1216120a0c0059071a500d171b1541120410590110130a041217411f03005918100094"
cipher_bytes = bytes.fromhex(cipher_hex)

# Known plaintext
known_plain = b"This is a known message to help you recover the key."

# Derive key via XOR
key = bytes([c ^ p for c, p in zip(cipher_bytes, known_plain)])
print("[+] Recovered Key:", key)

# Decrypt the encrypted flag
with open("encrypted_flag.bin", "rb") as f:
    encrypted_flag = f.read()

decrypted_flag = bytes([c ^ key[i % len(key)] for i, c in enumerate(encrypted_flag)])
print("[+] Decrypted Flag:", decrypted_flag.decode())
